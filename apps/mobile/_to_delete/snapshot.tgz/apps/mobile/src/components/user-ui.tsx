import Ionicons from '@expo/vector-icons/Ionicons';
import { router } from 'expo-router';
import type { ReactNode } from 'react';
import { Image, Pressable, ScrollView, Text, View } from 'react-native';
import { useS } from './figma';
import { TAB_BAR_SPACE } from './tab-bar';
import { colors } from '../theme';


/** "Join pebble for 3 days" */
export function daysWithPebble(createdAt?: string) {
  if (!createdAt) return '';
  const days = Math.max(1, Math.floor((Date.now() - new Date(createdAt).getTime()) / 86_400_000) + 1);
  return `อยู่กับ pebble มา ${days} วัน`;
}

export function Avatar({ size }: { size: number }) {
  const s = useS();
  return (
    <Image
      source={require('../../assets/images/setup/avatar.png')}
      style={{ width: s(size), height: s(size), borderRadius: 999, boxShadow: '0 6px 18px rgba(61,139,247,0.25)' }}
      accessibilityIgnoresInvertColors
    />
  );
}

/** White page with the soft blue top, a back arrow and a centred title (sub-pages of the User tab). */
export function SubPage({ title, icon, children }: { title: string; icon?: keyof typeof Ionicons.glyphMap; children: ReactNode }) {
  const s = useS();
  return (
    <View style={{ flex: 1, backgroundColor: colors.page }}>
      <ScrollView contentContainerStyle={{ paddingTop: s(88), paddingBottom: TAB_BAR_SPACE + 20 }} keyboardShouldPersistTaps="handled">
        <View style={{ height: s(40), justifyContent: 'center', alignItems: 'center', marginBottom: s(10) }}>
          <Pressable
            onPress={() => router.back()}
            hitSlop={12}
            accessibilityRole="button"
            accessibilityLabel="ย้อนกลับ"
            style={{ position: 'absolute', left: s(36), top: 0, bottom: 0, justifyContent: 'center' }}>
            <Ionicons name="chevron-back" size={s(20)} color={colors.ink} />
          </Pressable>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: s(8) }}>
            {icon ? <Ionicons name={icon} size={s(18)} color={colors.ink} /> : null}
            <Text style={{ fontSize: s(16), fontWeight: '500', color: colors.ink }}>{title}</Text>
          </View>
        </View>
        {children}
      </ScrollView>
    </View>
  );
}

/** Label + grey value row with a hairline under it (Login & Security, Appearance). */
export function InfoRow({
  label,
  value,
  right,
  onPress,
  last,
}: {
  label: string;
  value?: string;
  right?: ReactNode;
  onPress?: () => void;
  last?: boolean;
}) {
  const s = useS();
  return (
    <Pressable
      onPress={onPress}
      disabled={!onPress}
      accessibilityRole={onPress ? 'button' : undefined}
      style={{
        marginHorizontal: s(40),
        paddingVertical: s(12),
        flexDirection: 'row',
        alignItems: 'center',
        borderBottomWidth: last ? 0 : 1,
        borderBottomColor: colors.line,
      }}>
      <View style={{ flex: 1 }}>
        <Text style={{ fontSize: s(13), fontWeight: '500', color: colors.ink }}>{label}</Text>
        {value ? <Text style={{ fontSize: s(11), color: colors.muted, marginTop: s(2) }}>{value}</Text> : null}
      </View>
      {right}
      {onPress && !right ? <Ionicons name="chevron-forward" size={s(14)} color={colors.faint} /> : null}
    </Pressable>
  );
}
