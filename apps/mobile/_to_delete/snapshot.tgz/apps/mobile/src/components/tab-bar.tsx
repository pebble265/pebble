import Ionicons from '@expo/vector-icons/Ionicons';
import MaterialCommunityIcons from '@expo/vector-icons/MaterialCommunityIcons';
import { type ReactNode, useEffect, useState } from 'react';
import { Keyboard, LayoutAnimation, Platform, Pressable, Text, View, StyleSheet } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors, shadow, themedStyles } from '../theme';
import { useTheme } from '../lib/theme-mode';

/** Height the screens should leave free at the bottom so content isn't hidden under the bar. */
export const TAB_BAR_SPACE = 110;
/** Exact height the floating bar takes on this phone (pill + its padding + home indicator). */
export function useTabBarHeight() {
  const insets = useSafeAreaInsets();
  return 8 + 66 + Math.max(insets.bottom, 12);
}

/** True while the on-screen keyboard is up (the bar hides so inputs aren't covered). */
export function useKeyboardVisible() {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const show = Keyboard.addListener(Platform.OS === 'ios' ? 'keyboardWillShow' : 'keyboardDidShow', () => setVisible(true));
    const hide = Keyboard.addListener(Platform.OS === 'ios' ? 'keyboardWillHide' : 'keyboardDidHide', () => setVisible(false));
    return () => {
      show.remove();
      hide.remove();
    };
  }, []);
  return visible;
}

type Item = { route: string; label: string; icon(active: boolean): ReactNode; big(): ReactNode };

/** Every tab in its fixed order. The open one sits in the big round button; the rest stay in the pill. */
const ITEMS: Item[] = [
  {
    route: 'index',
    label: 'หน้าหลัก',
    icon: (a) => <Ionicons name={a ? 'home' : 'home-outline'} size={21} color={a ? colors.blue : colors.text} />,
    big: () => <Ionicons name="home" size={28} color={colors.red} />,
  },
  {
    route: 'meds',
    label: 'ยา',
    icon: (a) => <MaterialCommunityIcons name="pill" size={22} color={a ? colors.blue : colors.text} />,
    big: () => <MaterialCommunityIcons name="pill" size={30} color={colors.red} />,
  },
  {
    route: 'journal',
    label: 'บันทึก',
    icon: (a) => <Ionicons name={a ? 'journal' : 'journal-outline'} size={21} color={a ? colors.blue : colors.text} />,
    big: () => <Ionicons name="journal" size={27} color={colors.red} />,
  },
  {
    route: 'chat',
    label: 'Pebbi',
    icon: (a) => <MaterialCommunityIcons name="star-four-points" size={20} color={a ? colors.blue : colors.text} />,
    big: () => <MaterialCommunityIcons name="star-four-points" size={28} color={colors.red} />,
  },
  {
    route: 'robot',
    label: 'pebble',
    icon: (a) => <MaterialCommunityIcons name={a ? 'robot' : 'robot-outline'} size={22} color={a ? colors.blue : colors.text} />,
    big: () => <MaterialCommunityIcons name="robot" size={30} color={colors.red} />,
  },
  {
    route: 'me',
    label: 'โปรไฟล์',
    icon: (a) => <Ionicons name={a ? 'person' : 'person-outline'} size={21} color={a ? colors.blue : colors.text} />,
    big: () => <Ionicons name="person" size={27} color={colors.red} />,
  },
];

type Props = {
  state: { index: number; routes: { key: string; name: string }[] };
  navigateToTab(routeKey: string): void;
};

/**
 * The floating bar from the Figma Home screen: a frosted pill and a big round
 * button on the right. The round button always shows the open tab (Home at
 * first); the pill holds the other five in their fixed order.
 */
export function PebbleTabBar({ state, navigateToTab }: Props) {
  useTheme();
  const insets = useSafeAreaInsets();
  const current = state.routes[state.index]?.name;
  const keyboard = useKeyboardVisible();
  if (keyboard) return null;
  const go = (name: string) => {
    if (name === current) return;
    const route = state.routes.find((r) => r.name === name);
    if (!route) return;
    // Tapped tab slides into the round button, the previous one slides back to its slot.
    LayoutAnimation.configureNext(LayoutAnimation.create(220, 'easeInEaseOut', 'opacity'));
    navigateToTab(route.key);
  };
  const active = ITEMS.find((it) => it.route === current) ?? ITEMS[0];
  const others = ITEMS.filter((it) => it !== active);

  return (
    <View pointerEvents="box-none" style={[styles.wrap, { paddingBottom: Math.max(insets.bottom, 12) }]}>
      <View style={styles.pill}>
        {others.map((it) => (
          <Pressable
            key={it.route}
            onPress={() => go(it.route)}
            accessibilityRole="tab"
            accessibilityState={{ selected: false }}
            accessibilityLabel={it.label}
            style={styles.item}>
            {it.icon(false)}
            <Text style={styles.label} numberOfLines={1}>
              {it.label}
            </Text>
          </Pressable>
        ))}
      </View>
      <View
        key={active.route}
        accessibilityRole="tab"
        accessibilityState={{ selected: true }}
        accessibilityLabel={active.label}
        style={styles.home}>
        {active.big()}
      </View>
    </View>
  );
}

const styles = themedStyles(() =>
  StyleSheet.create({
  wrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 14,
    paddingTop: 8,
  },
  pill: {
    flex: 1,
    flexDirection: 'row',
    height: 66,
    borderRadius: 33,
    backgroundColor: colors.glass,
    borderWidth: 1,
    borderColor: colors.glass,
    boxShadow: shadow.float,
    paddingHorizontal: 6,
    alignItems: 'center',
    maxWidth: 520,
  },
  item: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 3, height: '100%' },
  label: { fontSize: 10, color: colors.text },
  home: {
    width: 66,
    height: 66,
    borderRadius: 33,
    backgroundColor: colors.glass,
    alignItems: 'center',
    justifyContent: 'center',
    boxShadow: shadow.float,
  },
}));
